-- Determine the distribution of orders by hour of the day.
SELECT 
    HOUR(order_time) AS Time, COUNT(order_id) AS No_of_Orders
FROM
    orders
GROUP BY HOUR(order_time)
