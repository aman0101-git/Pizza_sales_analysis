-- List the top 5 most ordered pizza types along with their quantities.
SELECT
pizza_types.name, SUM(order_details.Quantity) AS Quantity
FROM 
pizza_types join pizzas
ON pizza_types.pizza_type_id = pizzas.pizza_type_id
join order_details
ON order_details.Pizza_id = pizzas.pizza_id
group by pizza_types.name 
order by Quantity desc 
limit 5